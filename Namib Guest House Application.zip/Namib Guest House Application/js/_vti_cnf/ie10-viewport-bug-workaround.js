vti_encoding:SR|utf8-nl
vti_timelastmodified:TX|28 Jul 2017 06:58:02 -0000
vti_author:SR|DESKTOP-7T2EAIS\\User
vti_modifiedby:SR|DESKTOP-7T2EAIS\\User
vti_nexttolasttimemodified:TX|28 Jul 2017 06:58:02 -0000
vti_timecreated:TR|03 Oct 2017 12:18:06 -0000
vti_cacheddtm:TX|03 Oct 2017 12:18:06 -0000
vti_filesize:IR|641
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|Standard\\ template\\ framework/template.html
vti_syncofs_localhost\\f\:\\bcad semester 2\\it assignment preloads\\wede5010-namib guest house\\namib guest house\\expressiveweb code library/f\:/bcad semester 2/it assignment preloads/wede5010-namib guest house/namib guest house/expressiveweb code library:TX|28 Jul 2017 06:58:02 -0000
vti_syncwith_localhost\\f\:\\bcad semester 2\\it assignment preloads\\wede5010-namib guest house\\namib guest house\\expressiveweb code library/f\:/bcad semester 2/it assignment preloads/wede5010-namib guest house/namib guest house/expressiveweb code library:TW|03 Oct 2017 12:18:06 -0000
